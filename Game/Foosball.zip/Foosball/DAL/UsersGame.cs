﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class UsersGame
    {
        //static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myConnectionString"].ToString());
       static SqlConnection con = new SqlConnection("Data Source=WINCTRL-IPDDO5B\\SQLEXPRESS;Initial Catalog=Foosball;Integrated Security=True");

        //Creates a player.
        public static void SavePlayer(string name)
        {

            string qry = "insert into Players(Name) values(@name)";

            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@name", name);
           
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        //Creates a player.
        public static void SaveResult(string team,int teamAGoals,int teamBGoals)
        {

            string qry = "insert into Match(Team_Won,TeamA_Goals,TeamB_Goals) values(@team,@teamAGoals,@teamBGoals)";

            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@team", team);
            cmd.Parameters.AddWithValue("@teamAGoals", teamAGoals);
            cmd.Parameters.AddWithValue("@teamBGoals", teamBGoals);


            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        //Returns the list of players for selection.
        public static List<STO.User> PlayerList()
        {           
            try
            {

                SqlCommand cmd = new SqlCommand("select * from Players ", con);               
                con.Open();
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                ad.Fill(ds);


                STO.User user = new STO.User();
                List<STO.User> listValues = new List<STO.User>();
                foreach (DataRow dr in ds.Tables[0].Rows)
                {                  
                    listValues.Add(new STO.User {  Name = Convert.ToString(dr["Name"]) });
                }
                return listValues;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }

        }

        //Saves team members.
        public static STO.User AddTeam(string player1, string player2)
        {
            try
            {
                
                string qry = "insert into Teams(Player1,Player2) values(@player1,@player2)";
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.Parameters.AddWithValue("@player1", player1);
                cmd.Parameters.AddWithValue("@player2", player2);
                

                con.Open();
                cmd.ExecuteNonQuery();

                var user = new STO.User();
                return user;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }

        }

        //Shows the results of every match.
        public static List<STO.User> ShowGrid()
        {
            try
            {

                SqlCommand cmd = new SqlCommand("select * from Match ", con);
                con.Open();
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                ad.Fill(ds);


                STO.User user = new STO.User();
                List<STO.User> listValues = new List<STO.User>();
                foreach (DataRow dr in ds.Tables[0].Rows)
                {

                    listValues.Add(new STO.User { Team_Won = Convert.ToString(dr["Team_Won"]), TeamA_Goals = Convert.ToInt16(dr["TeamA_Goals"]), TeamB_Goals = Convert.ToInt16(dr["TeamB_Goals"])  });
                }
                return listValues;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }

        }


    }


}
