﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class UserGame
    {
        public static void SavePlayer(string name)
        {

            DAL.UsersGame.SavePlayer(name);
        }

        public static void SaveResult(string team, int teamAGoals, int teamBGoals)
        {
            DAL.UsersGame.SaveResult(team, teamAGoals, teamBGoals);
        }
        public static List<STO.User> PlayerList()
        {
           
            return DAL.UsersGame.PlayerList();
            
        }

        public static List<STO.User> ShowGrid()
        {

            return DAL.UsersGame.ShowGrid();

        }
        public static STO.User AddTeam(string player1, string player2)
        {

            return DAL.UsersGame.AddTeam(player1, player2);
        }
    }
}
