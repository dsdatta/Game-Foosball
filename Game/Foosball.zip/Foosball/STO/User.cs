﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STO
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Team_Won { get; set; }
        public int TeamA_Goals { get; set; }
        public int TeamB_Goals { get; set; }

    }
}
