﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Foosball
{
    public partial class CreateTeam : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Button3.Visible = false;
            if (!IsPostBack)
            {
                Session.Clear();
                Panel1.Visible = false;
                DropDownList3.DataSource = BLL.UserGame.PlayerList();
                DropDownList3.DataTextField = "Name";
                DropDownList3.DataValueField = "Id";
               
                DropDownList3.DataBind();

                DropDownList4.DataSource = BLL.UserGame.PlayerList();
                DropDownList4.DataTextField = "Name";
                DropDownList4.DataValueField = "Id";
                
                DropDownList4.DataBind();                

            }

            if (hdnfldVariable.Value != "")
            {
                Session["Player1"] = hdnfldVariable.Value;
            }
            if (HiddenField1.Value != "")
            {
                Session["Player2"] = HiddenField1.Value;
            }
            if (HiddenField2.Value != "")
            {
                Session["Player3"] = HiddenField2.Value;
            }
            if (HiddenField2.Value != "")
            {
                Session["Player4"] = HiddenField3.Value;
            }

            if(!string.IsNullOrEmpty(Session["Player1"] as string) && !string.IsNullOrEmpty(Session["Player1"] as string )&& !string.IsNullOrEmpty(Session["Player2"] as string) && !string.IsNullOrEmpty(Session["Player3"] as string) && !string.IsNullOrEmpty(Session["Player4"] as string))
                    {
                Button3.Visible = true;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;

            DropDownList3.Visible = false;
            DropDownList4.Visible = false;
            DropDownList1.Visible = true;
            DropDownList2.Visible = true;

            DropDownList1.DataTextField = "Name";
            DropDownList1.DataValueField = "Id";
            DropDownList1.DataSource = BLL.UserGame.PlayerList();
            DropDownList1.DataBind();

            DropDownList2.DataTextField = "Name";
            DropDownList2.DataValueField = "Id";
            DropDownList2.DataSource = BLL.UserGame.PlayerList();
            DropDownList2.DataBind();
            //Button2.Enabled = false;

           

           



        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;

            DropDownList1.Visible = false;
            DropDownList2.Visible = false;
            DropDownList3.Visible = true;
            DropDownList4.Visible = true;


            DropDownList3.DataTextField = "Name";
            DropDownList3.DataValueField = "Id";
            DropDownList3.DataSource = BLL.UserGame.PlayerList();
            DropDownList3.DataBind();

            DropDownList4.DataTextField = "Name";
            DropDownList4.DataValueField = "Id";
            DropDownList4.DataSource = BLL.UserGame.PlayerList();
            DropDownList4.DataBind();


           /// Button1.Enabled = false;

        }

        protected void Button4_Click(object sender, EventArgs e)
        {

            
            Panel1.Visible = false;
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = DropDownList3.SelectedItem.Value;
            Session["Name"] = name;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("PlayGame.aspx");
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}