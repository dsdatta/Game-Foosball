﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Foosball
{
    public partial class PlayGame : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Label1.Text =Convert.ToString( Session["Name"]);
            Label1.Text = Convert.ToString(Session["Player1"]);
            Label3.Text= Convert.ToString(Session["Player2"]);
            Label2.Text= Convert.ToString(Session["Player3"]);
            Label4.Text= Convert.ToString(Session["Player4"]);
            int count=0;
            int count1=0;
            
            if (TextBox3.Text != "" || TextBox4.Text != "" )
            {
                if(TextBox3.Text == "")
                {
                    TextBox3.Text = "0";
                }
                if (TextBox4.Text == "")
                {
                    TextBox4.Text = "0";
                }
                count = Convert.ToInt16(TextBox3.Text) + Convert.ToInt16(TextBox4.Text);
                Label9.Visible = true;
                Label7.Visible = true;
                Label7.Text = Convert.ToString(count);
            }
            if (TextBox1.Text != "" || TextBox2.Text != "")
            {
                if (TextBox1.Text == "")
                {
                    TextBox1.Text = "0";
                }
                if (TextBox2.Text == "")
                {
                    TextBox2.Text = "0";
                }
                count1 = Convert.ToInt16(TextBox1.Text) + Convert.ToInt16(TextBox2.Text);
                Label10.Visible = true;
                Label8.Visible = true;
                Label8.Text = Convert.ToString(count1);
            }

            if(count==10||count1==10)
            {
               
                string won = "";
                if (count == 10)
                {
                    won = "Team A";
                }
                else
                {
                    won = "Team B";
                }
                
                    BLL.UserGame.SaveResult(won, count, count1);
              
                TextBox1.Enabled = false;
                TextBox1.Text = "";
                TextBox2.Enabled = false;
                TextBox2.Text = "";
                TextBox3.Enabled = false;
                TextBox3.Text = "";
                TextBox4.Enabled = false;
                TextBox4.Text = "";
                Label9.Text = "Congratulations! "+ won +" Won";
                Label7.Visible=false;
                Label8.Visible=false;
                Label10.Visible = false;
                count = 0;
                 count1 = 0;
                Button2.Visible = true;


            }


           

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("CreateTeam.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("GameStats.aspx");
        }
    }
}